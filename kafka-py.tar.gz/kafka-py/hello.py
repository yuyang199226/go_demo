import time

while True:
    print("hello world")
    time.sleep(1)