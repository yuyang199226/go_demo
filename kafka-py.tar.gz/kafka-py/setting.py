#!/usr/bin/env python

kafka_setting = {
    'sasl_plain_username': '',
    'sasl_plain_password': '',
    #'bootstrap_servers': "manage28.aibee.cn:30091,manage29.aibee.cn:30092,manage30.aibee.cn:30093",
    'bootstrap_servers':"kafka-n1:9092",
    'consumer_id': 'public-store-online-event-group'
}